# Personality Assessment

## Evidence

- [16Personalities test result](assets/personality_result.png)

## Reflection – STAR Technique

**Situation:** I completed a personality test as part of self-awareness development.  
**Task:** Identify strengths and areas for improvement.  
**Action:** Took the MBTI-based test and reviewed results.  
**Result:** I discovered I’m an INFJ – empathetic, creative, and detail-oriented – traits valuable for design and development.