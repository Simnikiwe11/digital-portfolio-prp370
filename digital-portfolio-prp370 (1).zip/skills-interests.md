# Skills and Interests

## Evidence

- [HTML/CSS Certificate](assets/html_css_certificate.pdf)
- Screenshot of my React project

## Reflection – STAR Technique

**Situation:** I wanted to grow my technical skills.  
**Task:** Complete skill development courses and build real projects.  
**Action:** I enrolled in online courses and created web applications.  
**Result:** I built confidence in using HTML, CSS, JavaScript, and React. I can now independently design and develop websites.