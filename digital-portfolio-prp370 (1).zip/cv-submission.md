# CV Submission

## Evidence

- Screenshot of submission page on Blackboard

## Reflection – STAR Technique

**Situation:** I submitted my CV as part of the Work Readiness training.  
**Task:** Meet course requirements and prepare for job applications.  
**Action:** Uploaded the document through Blackboard on time.  
**Result:** Successfully submitted, and received feedback for improvement.