# Career Counselling

## Evidence

- [Career guidance notes (PDF)](assets/career_guidance.pdf)
- Screenshot of session with counsellor

## Reflection – STAR Technique

**Situation:** I attended a career counselling session during the semester.  
**Task:** Understand my career direction and align my learning.  
**Action:** Engaged with a counsellor, completed self-assessments, and explored roles like front-end developer.  
**Result:** I gained clarity on my career goals and committed to improving my portfolio and technical skills.