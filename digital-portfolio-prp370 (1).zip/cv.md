# Curriculum Vitae

## Evidence

- [Download My CV (PDF)](assets/simnikiwe-mfethe-cv.pdf)

## Reflection – STAR Technique

**Situation:** I needed to prepare a CV for internship applications.  
**Task:** Create a clear, professional document that highlights my education and experience.  
**Action:** Used a template, included academic history, skills, and projects.  
**Result:** I now have a polished CV ready for real-world opportunities.