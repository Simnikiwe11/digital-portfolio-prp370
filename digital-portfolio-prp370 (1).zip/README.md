# Simnikiwe Mfethe's Digital Portfolio

Welcome to my digital portfolio for the PRP370-1-2S course at CPUT.  
This e-portfolio showcases my journey, experiences, and reflections using the STAR technique.

---

## Contents

- [Career Counselling](career-counselling.md)
- [Skills & Interests](skills-interests.md)
- [Personality Assessment](personality-assessment.md)
- [My CV](cv.md)
- [CV Submission](cv-submission.md)